import './App.css'
import Trips from './components/Trips'

function App() {
  return (
    <div className="App">
      <Trips/>
    </div>
  )
}

export default App